const GalleryFooter = () => {
    return (
        <footer className="flex justify-center items-center text-white text-center harry-text-small mt-12">
        <p className="text-center">© 2021 Exodia, IIT Mandi</p>
        </footer>
    );
};

export default GalleryFooter;